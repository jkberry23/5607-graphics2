Created by Jason Berry, 1/22/24
	UMN CSCI 5607, Assignment 0

This program creates an ASCII PPM file representing a black rectangle of the specified height and width.
It takes as input the name of a file in the "./input/" directory.

Usage:
	python3 ppm_generator.py <filename>

File Contents:
	imsize <width> <height>